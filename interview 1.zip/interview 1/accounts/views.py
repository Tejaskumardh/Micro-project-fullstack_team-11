from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from .models import Profile


def register(request):
    """User registration view."""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Profile is created automatically by signal with display_name set
            # Just ensure it exists and update if needed
            profile, created = Profile.objects.get_or_create(
                user=user,
                defaults={'display_name': user.username}
            )
            if not created and not profile.display_name:
                profile.display_name = user.username
                profile.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()
    
    return render(request, 'accounts/register.html', {'form': form})


@login_required
def profile(request):
    """User profile view."""
    profile, _ = Profile.objects.get_or_create(user=request.user)
    
    if request.method == 'POST':
        display_name = request.POST.get('display_name', '')
        if display_name:
            profile.display_name = display_name
            profile.save()
            return redirect('profile')
    
    return render(request, 'accounts/profile.html', {'profile': profile})
