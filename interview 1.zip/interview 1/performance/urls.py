from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='performance_dashboard'),
    path('api/score-history/', views.score_history_api, name='score_history_api'),
    path('api/topic-proficiency/', views.topic_proficiency_api, name='topic_proficiency_api'),
    path('api/time-analysis/', views.time_analysis_api, name='time_analysis_api'),
    path('api/weakness-detection/', views.weakness_detection_api, name='weakness_detection_api'),
]

