from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.utils import timezone
from datetime import timedelta
from preparations.models import Attempt
from accounts.models import Profile
from gamification.models import UserBadge, Badge


@login_required
def dashboard(request):
    """Performance dashboard with charts."""
    profile, _ = Profile.objects.get_or_create(user=request.user)
    
    # Get badges
    user_badges = UserBadge.objects.filter(user=request.user).select_related('badge')
    
    context = {
        'profile': profile,
        'user_badges': user_badges,
    }
    return render(request, 'performance/dashboard.html', context)


def score_history_api(request):
    """API endpoint for score history chart."""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Not authenticated'}, status=401)
    
    # Get last 30 days of quiz attempts
    thirty_days_ago = timezone.now() - timedelta(days=30)
    attempts = Attempt.objects.filter(
        user=request.user,
        mode='QUIZ',
        created_at__gte=thirty_days_ago
    ).order_by('created_at')
    
    dates = []
    scores = []
    
    for attempt in attempts:
        dates.append(attempt.created_at.strftime('%Y-%m-%d'))
        scores.append(attempt.score)
    
    return JsonResponse({
        'dates': dates,
        'scores': scores,
    })


def topic_proficiency_api(request):
    """API endpoint for topic proficiency chart."""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Not authenticated'}, status=401)
    
    # Get all attempts grouped by topic
    attempts = Attempt.objects.filter(user=request.user, is_correct=True)
    
    topic_stats = {}
    for attempt in attempts:
        topic = attempt.question.topic
        if topic not in topic_stats:
            topic_stats[topic] = {'correct': 0, 'total': 0}
        topic_stats[topic]['correct'] += 1
    
    # Get total attempts per topic
    all_attempts = Attempt.objects.filter(user=request.user)
    for attempt in all_attempts:
        topic = attempt.question.topic
        if topic not in topic_stats:
            topic_stats[topic] = {'correct': 0, 'total': 0}
        topic_stats[topic]['total'] += 1
    
    topics = []
    percentages = []
    
    for topic, stats in topic_stats.items():
        if stats['total'] > 0:
            percentage = (stats['correct'] / stats['total']) * 100
            topics.append(topic)
            percentages.append(round(percentage, 1))
    
    return JsonResponse({
        'topics': topics,
        'percentages': percentages,
    })


def time_analysis_api(request):
    """API endpoint for time analysis chart."""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Not authenticated'}, status=401)
    
    # Get aptitude attempts
    aptitude_attempts = Attempt.objects.filter(
        user=request.user,
        section='APTITUDE'
    ).order_by('-created_at')[:50]
    
    if not aptitude_attempts:
        return JsonResponse({
            'topics': [],
            'avg_times': [],
            'ideal_times': [],
        })
    
    # Group by topic
    topic_times = {}
    for attempt in aptitude_attempts:
        topic = attempt.question.topic
        if topic not in topic_times:
            topic_times[topic] = []
        topic_times[topic].append(attempt.time_spent_seconds)
    
    topics = []
    avg_times = []
    ideal_times = []
    
    for topic, times in topic_times.items():
        if times:
            avg_time = sum(times) / len(times)
            topics.append(topic)
            avg_times.append(round(avg_time, 1))
            ideal_times.append(60)  # Ideal time per question
    
    return JsonResponse({
        'topics': topics,
        'avg_times': avg_times,
        'ideal_times': ideal_times,
    })


def weakness_detection_api(request):
    """API endpoint for weakness detection."""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Not authenticated'}, status=401)
    
    # Get last 50 attempts
    recent_attempts = Attempt.objects.filter(
        user=request.user
    ).order_by('-created_at')[:50]
    
    topic_accuracy = {}
    
    for attempt in recent_attempts:
        topic = attempt.question.topic
        if topic not in topic_accuracy:
            topic_accuracy[topic] = {'correct': 0, 'total': 0}
        
        topic_accuracy[topic]['total'] += 1
        if attempt.is_correct:
            topic_accuracy[topic]['correct'] += 1
    
    # Find weakest topic
    weakest_topic = None
    lowest_accuracy = 100
    
    for topic, stats in topic_accuracy.items():
        if stats['total'] >= 3:  # At least 3 attempts
            accuracy = (stats['correct'] / stats['total']) * 100
            if accuracy < lowest_accuracy:
                lowest_accuracy = accuracy
                weakest_topic = topic
    
    return JsonResponse({
        'weakest_topic': weakest_topic,
        'accuracy': round(lowest_accuracy, 1) if weakest_topic else None,
    })
