from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='preparations_index'),
    path('technical/<int:question_id>/', views.question_detail, name='question_detail'),
    path('aptitude/quiz/', views.aptitude_quiz, name='aptitude_quiz'),
    path('hr/', views.hr_practice, name='hr_practice'),
    path('api/submit-quiz/', views.submit_quiz, name='submit_quiz'),
    path('api/submit-answer/', views.submit_answer, name='submit_answer'),
    path('api/rate-question/', views.rate_question, name='rate_question'),
    path('api/save-hr-recording/', views.save_hr_recording, name='save_hr_recording'),
]

