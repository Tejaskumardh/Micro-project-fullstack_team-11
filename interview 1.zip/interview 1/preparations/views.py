from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.utils import timezone
from .models import Question, Attempt, Rating, HRRecording
from gamification.services import award_points
import json


@login_required
def index(request):
    """Preparations index with tabs and filters."""
    section = request.GET.get('section', 'TECHNICAL')
    difficulty = request.GET.get('difficulty', '')
    topic = request.GET.get('topic', '')
    mode = request.GET.get('mode', 'STUDY')
    
    questions = Question.objects.filter(section=section)
    
    if difficulty:
        questions = questions.filter(difficulty=difficulty)
    if topic:
        questions = questions.filter(topic__icontains=topic)
    
    # Get unique topics for filter
    topics = Question.objects.filter(section=section).values_list('topic', flat=True).distinct()
    
    context = {
        'questions': questions,
        'current_section': section,
        'current_difficulty': difficulty,
        'current_topic': topic,
        'current_mode': mode,
        'topics': topics,
    }
    return render(request, 'preparations/index.html', context)


@login_required
def question_detail(request, question_id):
    """Question detail view with Monaco editor support."""
    question = get_object_or_404(Question, pk=question_id)
    
    # Get user's previous attempt if any
    previous_attempt = Attempt.objects.filter(
        user=request.user,
        question=question
    ).order_by('-created_at').first()
    
    # Get user's rating
    user_rating = None
    if request.user.is_authenticated:
        try:
            user_rating = Rating.objects.get(user=request.user, question=question)
        except Rating.DoesNotExist:
            pass
    
    context = {
        'question': question,
        'previous_attempt': previous_attempt,
        'user_rating': user_rating,
    }
    return render(request, 'preparations/question_detail.html', context)


@login_required
def aptitude_quiz(request):
    """Aptitude quiz with timer."""
    count = int(request.GET.get('count', 10))
    questions = Question.objects.filter(section='APTITUDE').order_by('?')[:count]
    
    context = {
        'questions': questions,
        'count': count,
    }
    return render(request, 'preparations/aptitude_quiz.html', context)


@login_required
@require_POST
def submit_quiz(request):
    """Submit quiz answers and create attempts."""
    data = json.loads(request.body)
    answers = data.get('answers', {})
    time_spent = data.get('time_spent', 0)
    mode = data.get('mode', 'QUIZ')
    
    results = []
    total_score = 0
    
    for question_id_str, answer_data in answers.items():
        question_id = int(question_id_str)
        question = get_object_or_404(Question, pk=question_id)
        
        # Check if answer is correct
        is_correct = False
        if question.choices and question.correct_index is not None:
            selected_index = answer_data.get('selected_index')
            is_correct = (selected_index == question.correct_index)
        else:
            # For non-MCQ questions, compare text
            submitted_text = answer_data.get('text', '').strip().lower()
            is_correct = submitted_text in question.answer.lower()
        
        # Calculate score for aptitude
        score = 10 if is_correct else 0
        if question.section == 'APTITUDE' and is_correct:
            # Bonus for speed
            time_per_question = time_spent / len(answers) if answers else 0
            if time_per_question < 60:
                score += 5
        
        # Create attempt
        attempt = Attempt.objects.create(
            user=request.user,
            question=question,
            section=question.section,
            mode=mode,
            is_correct=is_correct,
            time_spent_seconds=int(time_spent / len(answers)) if answers else 0,
            submitted_answer=str(answer_data),
            score=score
        )
        
        total_score += score
        results.append({
            'question_id': question_id,
            'is_correct': is_correct,
            'correct_answer': question.choices[question.correct_index] if question.choices and question.correct_index is not None else question.answer,
            'explanation': question.answer,
        })
    
    # Award points for quiz completion
    award_points(request.user, 20)
    
    return JsonResponse({
        'results': results,
        'total_score': total_score,
        'correct_count': sum(1 for r in results if r['is_correct']),
    })


@login_required
def hr_practice(request):
    """HR practice page with recording widget."""
    questions = Question.objects.filter(section='HR')
    
    context = {
        'questions': questions,
    }
    return render(request, 'preparations/hr_practice.html', context)


@login_required
@require_POST
def save_hr_recording(request):
    """Save HR recording."""
    data = json.loads(request.body)
    question_id = data.get('question_id')
    blob_path = data.get('blob_path', '')
    duration = data.get('duration', 0)
    
    question = get_object_or_404(Question, pk=question_id)
    
    recording = HRRecording.objects.create(
        user=request.user,
        question=question,
        blob_path=blob_path,
        duration_seconds=duration
    )
    
    return JsonResponse({'success': True, 'recording_id': recording.id})


@login_required
@require_POST
def submit_answer(request):
    """Submit answer for a single question (study mode)."""
    data = json.loads(request.body)
    question_id = data.get('question_id')
    selected_index = data.get('selected_index')
    time_spent = data.get('time_spent', 0)
    mode = data.get('mode', 'STUDY')
    
    question = get_object_or_404(Question, pk=question_id)
    
    # Check if answer is correct
    is_correct = False
    if question.choices and question.correct_index is not None:
        is_correct = (selected_index == question.correct_index)
    
    # Create attempt
    attempt = Attempt.objects.create(
        user=request.user,
        question=question,
        section=question.section,
        mode=mode,
        is_correct=is_correct,
        time_spent_seconds=time_spent,
        submitted_answer=str(selected_index),
        score=10 if is_correct else 0
    )
    
    return JsonResponse({
        'is_correct': is_correct,
        'correct_index': question.correct_index,
        'explanation': question.answer,
    })


@login_required
@require_POST
def rate_question(request):
    """Rate a question."""
    data = json.loads(request.body)
    question_id = data.get('question_id')
    stars = int(data.get('stars', 5))
    
    question = get_object_or_404(Question, pk=question_id)
    
    rating, created = Rating.objects.update_or_create(
        user=request.user,
        question=question,
        defaults={'stars': stars}
    )
    
    return JsonResponse({'success': True, 'rating': rating.stars})
