from django.db import models
from django.contrib.auth.models import User


class Question(models.Model):
    SECTION_CHOICES = [
        ("TECHNICAL", "TECHNICAL"),
        ("APTITUDE", "APTITUDE"),
        ("HR", "HR"),
    ]
    
    DIFFICULTY_CHOICES = [
        ("BEGINNER", "BEGINNER"),
        ("INTERMEDIATE", "INTERMEDIATE"),
        ("ADVANCED", "ADVANCED"),
    ]
    
    title = models.CharField(max_length=200)
    section = models.CharField(max_length=20, choices=SECTION_CHOICES)
    difficulty = models.CharField(max_length=20, choices=DIFFICULTY_CHOICES, default="BEGINNER")
    topic = models.CharField(max_length=100)
    prompt = models.TextField()
    answer = models.TextField()
    
    # MCQ fields
    choices = models.JSONField(null=True, blank=True)  # list of 4 strings
    correct_index = models.PositiveSmallIntegerField(null=True, blank=True)  # 0..3
    
    # Optional learning aids
    video_url = models.URLField(blank=True)
    io_samples = models.JSONField(null=True, blank=True)  # for code-playground Qs
    
    created_at = models.DateTimeField(auto_now_add=True, null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True, null=True, blank=True)
    
    def __str__(self):
        return f"{self.title} ({self.section})"


class Attempt(models.Model):
    MODE_CHOICES = [
        ("STUDY", "STUDY"),
        ("QUIZ", "QUIZ"),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    section = models.CharField(max_length=20)
    mode = models.CharField(max_length=10, choices=MODE_CHOICES)
    is_correct = models.BooleanField()
    time_spent_seconds = models.IntegerField(default=0)
    submitted_answer = models.TextField(blank=True)
    score = models.IntegerField(default=0)  # aptitude timed score
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.question.title} ({'✓' if self.is_correct else '✗'})"


class HRRecording(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    blob_path = models.CharField(max_length=255)
    duration_seconds = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.question.title} ({self.duration_seconds}s)"


class Rating(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    stars = models.PositiveSmallIntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['user', 'question']
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.question.title} ({self.stars}★)"
