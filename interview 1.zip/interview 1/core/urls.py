from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('api/progress/summary/', views.progress_summary_api, name='progress_summary_api'),
]

