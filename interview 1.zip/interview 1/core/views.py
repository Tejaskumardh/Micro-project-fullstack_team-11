from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from preparations.models import Question, Attempt
from accounts.models import Profile
from gamification.models import UserBadge


@login_required
def home(request):
    """Home dashboard view."""
    try:
        profile = Profile.objects.get(user=request.user)
    except Profile.DoesNotExist:
        profile = Profile.objects.create(user=request.user, display_name=request.user.username)
    
    # Get progress stats
    total_questions = Question.objects.count() or 60  # Default to 60 if count fails
    completed_questions = Attempt.objects.filter(
        user=request.user
    ).values('question').distinct().count()
    
    # Get last quiz attempt
    last_quiz = Attempt.objects.filter(
        user=request.user,
        mode="QUIZ"
    ).order_by('-created_at').first()
    
    # Get recent badges
    recent_badges = UserBadge.objects.filter(
        user=request.user
    ).select_related('badge').order_by('-awarded_at')[:5]
    
    context = {
        'profile': profile,
        'total_questions': total_questions,
        'completed_questions': completed_questions,
        'last_quiz': last_quiz,
        'recent_badges': recent_badges,
    }
    return render(request, 'core/home.html', context)


def progress_summary_api(request):
    """JSON API endpoint for progress summary."""
    if not request.user.is_authenticated:
        return JsonResponse({'error': 'Not authenticated'}, status=401)
    
    total_questions = Question.objects.count()
    completed_questions = Attempt.objects.filter(
        user=request.user
    ).values('question').distinct().count()
    
    technical_correct = Attempt.objects.filter(
        user=request.user,
        section="TECHNICAL",
        is_correct=True
    ).count()
    
    aptitude_correct = Attempt.objects.filter(
        user=request.user,
        section="APTITUDE",
        is_correct=True
    ).count()
    
    hr_recordings = Attempt.objects.filter(
        user=request.user,
        section="HR"
    ).count()
    
    profile, _ = Profile.objects.get_or_create(user=request.user)
    
    return JsonResponse({
        'total_questions': total_questions,
        'completed_questions': completed_questions,
        'technical_correct': technical_correct,
        'aptitude_correct': aptitude_correct,
        'hr_recordings': hr_recordings,
        'points': profile.points,
        'streak_days': profile.streak_days,
    })
