// Performance charts using Chart.js
(function() {
    // Score History Chart
    fetch('/performance/api/score-history/')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('scoreHistoryChart');
            if (ctx) {
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: data.dates,
                        datasets: [{
                            label: 'Score',
                            data: data.scores,
                            borderColor: 'rgb(59, 130, 246)',
                            backgroundColor: 'rgba(59, 130, 246, 0.1)',
                            tension: 0.1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }
        })
        .catch(error => console.error('Error loading score history:', error));
    
    // Topic Proficiency Chart
    fetch('/performance/api/topic-proficiency/')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('topicProficiencyChart');
            if (ctx) {
                new Chart(ctx, {
                    type: 'radar',
                    data: {
                        labels: data.topics,
                        datasets: [{
                            label: 'Proficiency %',
                            data: data.percentages,
                            borderColor: 'rgb(34, 197, 94)',
                            backgroundColor: 'rgba(34, 197, 94, 0.2)',
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        scales: {
                            r: {
                                beginAtZero: true,
                                max: 100
                            }
                        }
                    }
                });
            }
        })
        .catch(error => console.error('Error loading topic proficiency:', error));
    
    // Time Analysis Chart
    fetch('/performance/api/time-analysis/')
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById('timeAnalysisChart');
            if (ctx && data.topics.length > 0) {
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: data.topics,
                        datasets: [
                            {
                                label: 'Avg Time (s)',
                                data: data.avg_times,
                                backgroundColor: 'rgba(59, 130, 246, 0.5)',
                            },
                            {
                                label: 'Ideal Time (s)',
                                data: data.ideal_times,
                                backgroundColor: 'rgba(34, 197, 94, 0.5)',
                            }
                        ]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }
        })
        .catch(error => console.error('Error loading time analysis:', error));
    
    // Weakness Detection
    fetch('/performance/api/weakness-detection/')
        .then(response => response.json())
        .then(data => {
            const weaknessCard = document.getElementById('weaknessCard');
            if (weaknessCard) {
                if (data.weakest_topic) {
                    weaknessCard.innerHTML = `
                        <div class="p-4 bg-red-50 dark:bg-red-900 rounded-lg">
                            <h3 class="font-semibold text-red-800 dark:text-red-200 mb-2">Weakest Topic</h3>
                            <p class="text-lg font-bold text-red-900 dark:text-red-100">${data.weakest_topic}</p>
                            <p class="text-sm text-red-700 dark:text-red-300 mt-2">Accuracy: ${data.accuracy}%</p>
                            <a href="/prep/?section=TECHNICAL&topic=${encodeURIComponent(data.weakest_topic)}" class="mt-4 inline-block bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md">
                                Practice This Topic
                            </a>
                        </div>
                    `;
                } else {
                    weaknessCard.innerHTML = '<p class="text-gray-600 dark:text-gray-300">Not enough data yet. Keep practicing!</p>';
                }
            }
        })
        .catch(error => console.error('Error loading weakness detection:', error));
})();

