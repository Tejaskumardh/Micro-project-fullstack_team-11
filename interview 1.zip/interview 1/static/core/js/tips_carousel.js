// Tips carousel functionality
(function() {
    let currentTip = 0;
    const tips = document.querySelectorAll('.tip-item');
    const prevButton = document.getElementById('prevTip');
    const nextButton = document.getElementById('nextTip');
    
    if (tips.length === 0) return;
    
    function showTip(index) {
        tips.forEach((tip, i) => {
            if (i === index) {
                tip.classList.remove('hidden');
            } else {
                tip.classList.add('hidden');
            }
        });
    }
    
    function nextTip() {
        currentTip = (currentTip + 1) % tips.length;
        showTip(currentTip);
    }
    
    function prevTip() {
        currentTip = (currentTip - 1 + tips.length) % tips.length;
        showTip(currentTip);
    }
    
    if (prevButton) {
        prevButton.addEventListener('click', prevTip);
    }
    
    if (nextButton) {
        nextButton.addEventListener('click', nextTip);
    }
    
    // Auto-rotate every 5 seconds
    setInterval(nextTip, 5000);
    
    // Initialize
    showTip(0);
})();

