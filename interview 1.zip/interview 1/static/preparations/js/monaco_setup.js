// Monaco Editor setup
(function() {
    const editorContainer = document.getElementById('monacoEditor');
    if (!editorContainer) return;
    
    require.config({ paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.45.0/min/vs' } });
    
    require(['vs/editor/editor.main'], function() {
        const editor = monaco.editor.create(editorContainer, {
            value: '// Write your code here\n',
            language: 'python',
            theme: document.documentElement.getAttribute('data-theme') === 'dark' ? 'vs-dark' : 'vs',
            readOnly: false,
            minimap: { enabled: false }
        });
        
        // Update theme when dark mode changes
        const observer = new MutationObserver(() => {
            const theme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'vs-dark' : 'vs';
            monaco.editor.setTheme(theme);
        });
        
        observer.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ['data-theme']
        });
        
        // Store editor globally for access
        window.monacoEditor = editor;
    });
})();

