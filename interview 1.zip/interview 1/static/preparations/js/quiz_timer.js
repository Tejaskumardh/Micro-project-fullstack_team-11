// Quiz timer functionality
(function() {
    const timerElement = document.getElementById('timer');
    if (!timerElement) return;
    
    let timeRemaining = 600; // 10 minutes in seconds
    let timerInterval = null;
    
    function updateTimer() {
        const minutes = Math.floor(timeRemaining / 60);
        const seconds = timeRemaining % 60;
        timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        
        if (timeRemaining <= 0) {
            clearInterval(timerInterval);
            // Auto-submit quiz
            const submitButton = document.getElementById('submitQuiz');
            if (submitButton) {
                submitButton.click();
            }
        }
        
        timeRemaining--;
    }
    
    // Start timer
    timerInterval = setInterval(updateTimer, 1000);
    updateTimer();
})();

