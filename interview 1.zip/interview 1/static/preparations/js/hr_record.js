// HR recording functionality
(function() {
    let mediaRecorder = null;
    let audioChunks = [];
    let currentQuestionId = null;
    
    document.querySelectorAll('.start-recording').forEach(button => {
        button.addEventListener('click', async () => {
            const questionId = button.dataset.questionId;
            currentQuestionId = questionId;
            
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder = new MediaRecorder(stream);
                audioChunks = [];
                
                mediaRecorder.ondataavailable = (event) => {
                    audioChunks.push(event.data);
                };
                
                mediaRecorder.onstop = () => {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
                    const audioUrl = URL.createObjectURL(audioBlob);
                    const audioElement = document.getElementById(`audio_${questionId}`);
                    
                    if (audioElement) {
                        audioElement.src = audioUrl;
                        audioElement.classList.remove('hidden');
                    }
                    
                    // Stop all tracks
                    stream.getTracks().forEach(track => track.stop());
                };
                
                mediaRecorder.start();
                
                // Update button states
                button.classList.add('hidden');
                document.querySelector(`.stop-recording[data-question-id="${questionId}"]`).classList.remove('hidden');
            } catch (error) {
                console.error('Error accessing microphone:', error);
                alert('Could not access microphone. Please check permissions.');
            }
        });
    });
    
    document.querySelectorAll('.stop-recording').forEach(button => {
        button.addEventListener('click', () => {
            if (mediaRecorder && mediaRecorder.state !== 'inactive') {
                mediaRecorder.stop();
                
                const questionId = button.dataset.questionId;
                button.classList.add('hidden');
                document.querySelector(`.start-recording[data-question-id="${questionId}"]`).classList.remove('hidden');
                document.querySelector(`.play-recording[data-question-id="${questionId}"]`).classList.remove('hidden');
                document.querySelector(`.save-recording[data-question-id="${questionId}"]`).classList.remove('hidden');
            }
        });
    });
    
    document.querySelectorAll('.play-recording').forEach(button => {
        button.addEventListener('click', () => {
            const questionId = button.dataset.questionId;
            const audioElement = document.getElementById(`audio_${questionId}`);
            if (audioElement) {
                audioElement.play();
            }
        });
    });
    
    document.querySelectorAll('.save-recording').forEach(button => {
        button.addEventListener('click', async () => {
            const questionId = button.dataset.questionId;
            const audioElement = document.getElementById(`audio_${questionId}`);
            
            if (!audioElement || !audioElement.src) {
                alert('No recording to save');
                return;
            }
            
            try {
                // Get CSRF token
                const csrftoken = getCsrfToken();
                
                // Save recording
                const saveResponse = await fetch(`/prep/api/save-hr-recording/`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': csrftoken
                    },
                    body: JSON.stringify({
                        question_id: questionId,
                        blob_path: `recordings/${questionId}_${Date.now()}.webm`,
                        duration: Math.floor(audioElement.duration || 0)
                    })
                });
                
                if (saveResponse.ok) {
                    alert('Recording saved successfully!');
                } else {
                    alert('Error saving recording');
                }
            } catch (error) {
                console.error('Error saving recording:', error);
                alert('Error saving recording');
            }
        });
    });
})();

