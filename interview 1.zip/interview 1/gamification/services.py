from django.contrib.auth.models import User
from .models import Badge, UserBadge
from preparations.models import Attempt, HRRecording
from accounts.models import Profile
from django.utils import timezone
from datetime import timedelta


def get_or_create_badge(code, name, description, icon=""):
    """Get or create a badge by code."""
    badge, created = Badge.objects.get_or_create(
        code=code,
        defaults={'name': name, 'description': description, 'icon': icon}
    )
    return badge


def award_badge(user, badge_code, name, description, icon=""):
    """Award a badge to a user if not already awarded."""
    badge = get_or_create_badge(badge_code, name, description, icon)
    user_badge, created = UserBadge.objects.get_or_create(
        user=user,
        badge=badge,
        defaults={'awarded_at': timezone.now()}
    )
    return user_badge, created


def check_algorithm_ace(user):
    """Award Algorithm Ace badge if user has ≥20 technical correct answers."""
    technical_correct = Attempt.objects.filter(
        user=user,
        section="TECHNICAL",
        is_correct=True
    ).count()
    
    if technical_correct >= 20:
        return award_badge(
            user,
            "ALGORITHM_ACE",
            "Algorithm Ace",
            "Solved 20+ technical questions correctly",
            "star"
        )
    return None, False


def check_hr_master(user):
    """Award HR Master badge if user has ≥10 HR recordings."""
    hr_recordings = HRRecording.objects.filter(user=user).count()
    
    if hr_recordings >= 10:
        return award_badge(
            user,
            "HR_MASTER",
            "HR Master",
            "Completed 10+ HR practice recordings",
            "microphone"
        )
    return None, False


def check_streak_keeper(user):
    """Award Streak Keeper badge if user has 7-day streak."""
    profile, _ = Profile.objects.get_or_create(user=user)
    
    if profile.streak_days >= 7:
        return award_badge(
            user,
            "STREAK_KEEPER",
            "Streak Keeper",
            "Maintained a 7-day activity streak",
            "flame"
        )
    return None, False


def check_speed_runner(user):
    """Award Speed Runner badge if avg time < ideal on 10 aptitude Qs."""
    aptitude_attempts = Attempt.objects.filter(
        user=user,
        section="APTITUDE",
        is_correct=True
    ).order_by('-created_at')[:10]
    
    if aptitude_attempts.count() >= 10:
        avg_time = sum(a.time_spent_seconds for a in aptitude_attempts) / 10
        ideal_time = 60  # 60 seconds per question
        
        if avg_time < ideal_time:
            return award_badge(
                user,
                "SPEED_RUNNER",
                "Speed Runner",
                "Average time < 60s on 10 aptitude questions",
                "bolt"
            )
    return None, False


def update_streak(user):
    """Update user's streak based on last activity."""
    profile, _ = Profile.objects.get_or_create(user=user)
    now = timezone.now()
    
    if profile.last_activity:
        days_diff = (now.date() - profile.last_activity.date()).days
        
        if days_diff == 1:
            # Consecutive day
            profile.streak_days += 1
        elif days_diff > 1:
            # Streak broken
            profile.streak_days = 1
        # days_diff == 0 means same day, don't increment
    else:
        # First activity
        profile.streak_days = 1
    
    profile.last_activity = now
    profile.save()
    
    # Check for streak badge
    check_streak_keeper(user)


def award_points(user, points):
    """Award points to user."""
    profile, _ = Profile.objects.get_or_create(user=user)
    profile.points += points
    profile.save()
    return profile.points

