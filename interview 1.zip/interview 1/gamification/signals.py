from django.db.models.signals import post_save
from django.dispatch import receiver
from preparations.models import Attempt, HRRecording
from gamification.services import (
    check_algorithm_ace, check_hr_master, check_speed_runner,
    update_streak, award_points
)


@receiver(post_save, sender=Attempt)
def handle_attempt_save(sender, instance, created, **kwargs):
    """Handle attempt save - award points and check badges."""
    if created:
        # Award points
        if instance.is_correct:
            award_points(instance.user, 10)
        
        # Update streak
        update_streak(instance.user)
        
        # Check badges based on section
        if instance.section == "TECHNICAL":
            check_algorithm_ace(instance.user)
        elif instance.section == "APTITUDE":
            check_speed_runner(instance.user)


@receiver(post_save, sender=HRRecording)
def handle_hr_recording_save(sender, instance, created, **kwargs):
    """Handle HR recording save - check badges."""
    if created:
        # Award points for HR recording
        award_points(instance.user, 5)
        
        # Update streak
        update_streak(instance.user)
        
        # Check HR master badge
        check_hr_master(instance.user)

