from django.db import models
from django.contrib.auth.models import User


class Badge(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=50, unique=True)
    description = models.TextField()
    icon = models.CharField(max_length=100, blank=True)  # icon name or path
    
    def __str__(self):
        return self.name


class UserBadge(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    badge = models.ForeignKey(Badge, on_delete=models.CASCADE)
    awarded_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['user', 'badge']
        ordering = ['-awarded_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.badge.name}"
